from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtGui import QBrush, QColor, QKeySequence
from functools import partial
from .growingtextedit import GrowingTextEdit


class EditorDelegate(QtWidgets.QStyledItemDelegate):
    def __init__(self, parent=None, customsignal=None):
        self.customsignal = customsignal
        super(EditorDelegate, self).__init__(parent)

    def createEditor(self, parent, option, index):
        textedit_widget = GrowingTextEdit(parent)
        textedit_widget.setFontPointSize(15)
        return textedit_widget

    def setEditorData(self, editor, index):
        editor.setPlainText(index.data())

    def setModelData(self, editor, model, index):
        model.setData(index, editor.toPlainText())

    def eventFilter(self, editor, event):
        if event.type() == QtCore.QEvent.FocusIn:
            if self.parent().autoplay_checkbox.isChecked():
                self.customsignal.start_signal.emit()

        if event.type() == QtCore.QEvent.FocusOut:
            self.customsignal.stop_signal.emit()

        if event.type() == QtCore.QEvent.KeyPress:
            if event.key() == QtCore.Qt.Key_Tab:
                self.customsignal.start_signal.emit()
                return True

            if event.key() == QtCore.Qt.Key_Escape:
                self.customsignal.stop_signal.emit()

            if event.modifiers() == QtCore.Qt.ControlModifier:
                if event.key() == QtCore.Qt.Key_Return:
                    self.customsignal.stop_signal.emit()
                    self.commitData.emit(editor)
                    self.closeEditor.emit(editor)
                    return True

        return super().eventFilter(editor, event)
