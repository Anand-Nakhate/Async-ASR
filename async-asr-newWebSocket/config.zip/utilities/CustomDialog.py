from PyQt5 import QtCore, QtGui, QtWidgets,Qt
import sys


class Dialog(QtWidgets.QDialog):
    def __init__(self, *args, **kwargs):
        super(Dialog, self).__init__(*args, **kwargs)
        self.setWindowFlags(QtCore.Qt.WindowSystemMenuHint | QtCore.Qt.WindowTitleHint)
        
        label = QtWidgets.QLabel("Save file as :")
        self.combo = QtWidgets.QComboBox()
        self.combo.addItems([".stm", ".TextGrid", ".srt", ".xml"])

        self.title = "PyQt5 Window"
        self.top = 200
        self.left = 500
        self.width = 400
        self.height = 300
        self.setModal(True)
        label2 = QtWidgets.QLabel("Do you want to overwrite your file?")
        self.box = QtWidgets.QDialogButtonBox()
        self.box.addButton("Save", QtWidgets.QDialogButtonBox.AcceptRole)
        self.box.addButton("Save as", QtWidgets.QDialogButtonBox.RejectRole)
        self.box.addButton("Cancel", QtWidgets.QDialogButtonBox.HelpRole)
        # self.box.accepted.connect(self.save)
        # self.box.helpRequested.connect(self.reject)
        # self.box.rejected.connect(self.saveas)
        lay = QtWidgets.QGridLayout(self)
        lay.addWidget(label, 0, 0)
        lay.addWidget(label2, 1, 0)
        lay.addWidget(self.combo, 0, 1)
        lay.addWidget(self.box, 2, 0,1,0)
        # Run the .setupUi() method to show the GUI
        self.resize(200, 120)
        
    # def save(self):
    #     self.savetype = "revision"
    #     print(self.combo.currentText() )
    #     self.accept()
    # def saveas(self):
    #     self.savetype = "overwrite"
    #     self.accept()
    # def reject(self):
    #     self.savetype = ""    
    #     self.accept()
        
class Window(QtWidgets.QMainWindow):
    """Main window."""
    def __init__(self, parent=None):
        """Initializer."""
        super().__init__(parent)
        self.centralWidget = QtWidgets.QPushButton("Employee...")
        self.centralWidget.clicked.connect(self.onEmployeeBtnClicked)
        self.setCentralWidget(self.centralWidget)
        
    def onEmployeeBtnClicked(self):
        """Launch the employee dialog."""
        dlg = Dialog()
        dlg.exec()
        
if __name__ == "__main__":
    # Create the application
    #app = QtWidgets.QApplication(sys.argv)
    # Create and show the application's main window
    dlg = Dialog()
    dlg.exec()
 