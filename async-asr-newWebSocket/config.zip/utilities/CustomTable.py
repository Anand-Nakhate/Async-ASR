import sys
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5 import QtCore, QtGui, QtWidgets


import copy 

class MyWindow(QtWidgets.QWidget):
    def __init__(self):
        QtWidgets.QWidget.__init__(self)
        
        
        
        self.c = 0
        # create table
        self.get_table_data()
        # self.table = self.createTable()
        self.conversation_table = CustomTableWidget()
        self.conversation_table.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.conversation_table.customContextMenuRequested.connect(self.generateMenu)
        self.conversation_table.viewport().installEventFilter(self)
        
        self.createCustomTable()
        self.PageNumberList = QtWidgets.QListWidget()
        self.PageNumberList.viewport().setAutoFillBackground( False );

        self.PageNumberList.setFlow(QtWidgets.QListView.LeftToRight) 
        self.PageNumberList.setFixedHeight(40)
        self.PageNumberList.itemClicked.connect(self.ListItemClicked)
        self.conversation_table.setpageListWidget(self.PageNumberList)
        # layout
        
        self.layout = QtWidgets.QVBoxLayout()
        self.testButton = QtWidgets.QPushButton("Add Data")
        self.testButton.clicked.connect(self.test)        
        self.layout.addWidget(self.testButton)
        self.layout.addWidget(self.conversation_table)
        
        self.Hlayout = QtWidgets.QHBoxLayout()
        self.next = QtWidgets.QPushButton()
        self.next.clicked.connect(self.nextButton)   
        self.next.setFixedWidth(25) 
        self.next.setFixedHeight(42) 
        self.next.setIcon(QtGui.QIcon(r"C:\Users\desmo\Desktop\FYP-Fork\async-asr\icons\right.png"))
        self.prev = QtWidgets.QPushButton()
        self.prev.clicked.connect(self.prevButton)  
        self.prev.setIcon(QtGui.QIcon(r"C:\Users\desmo\Desktop\FYP-Fork\async-asr\icons\left.png"))
        self.prev.setFixedWidth(25) 
        self.prev.setFixedHeight(42) 
        self.Hlayout.addWidget(self.prev)
        self.Hlayout.addWidget(self.PageNumberList)
        self.Hlayout.addWidget(self.next)
        self.Hlayout.setContentsMargins(QMargins(0,0,0,0))
        self.Hlayout.setSpacing(0)

        self.layout.addLayout(self.Hlayout)
        
        self.setLayout(self.layout)

    def eventFilter(self, source, event):
        if(event.type() == QtCore.QEvent.MouseButtonPress and
           event.buttons() == QtCore.Qt.RightButton and
           source is self.conversation_table.viewport()):
            item = self.conversation_table.itemAt(event.pos())
            #print('Global Pos:', event.globalPos())
            if item is not None:
                #print('Table Item:', item.row(), item.column())
                self.menu = QtWidgets.QMenu(self)
                self.action = QtWidgets.QAction("Bookmark")
                self.action.triggered.connect(self.bookMark)
                self.menu.addAction(self.action)        
                self.action2 = QtWidgets.QAction("Split Page")
                self.action2.triggered.connect(self.splitPage)
                self.menu.addAction(self.action2)        
                #menu.exec_(event.globalPos())
        return super(MyWindow, self).eventFilter(source, event)

    def bookMark(self):
        self.conversation_table.createBookMark()
        
    def splitPage(self):
        index = self.conversation_table.currentRow()
        self.conversation_table.splitPage(index)
       
    def generateMenu(self, pos):
        print("pos======",pos)
        self.menu.exec_(self.conversation_table.mapToGlobal(pos))   # +++

    def ListItemClicked(self):
        pageSelected = self.PageNumberList.selectedItems()[0].data(Qt.UserRole)
        self.conversation_table.switchPage(pageSelected)
        self.conversation_table.redrawList(pageSelected)
        
    
    def get_table_data(self):
        self.tabledata = [[1234567890,2,3,4,5],
                          [6,7,8,9,10],
                          [11,12,13,14,15],
                          [16,17,18,19,20]]
    def createCustomTable(self):
        self.conversation_table.setColumnCount(5)
        item = QtWidgets.QTableWidgetItem()
        self.conversation_table.setHorizontalHeaderItem(0, item)
        item = QtWidgets.QTableWidgetItem()
        self.conversation_table.setHorizontalHeaderItem(1, item)
        item = QtWidgets.QTableWidgetItem()
        self.conversation_table.setHorizontalHeaderItem(2, item)
        self.conversation_table.setIconSize(QtCore.QSize(32, 32))

    def createTable(self):
        item = QtWidgets.QTableWidgetItem()
        item.setText("Speakers")
        # self.conversation_table.setHorizontalHeaderItem(0, item)
        
        # create the view
        tv = QtWidgets.QTableView()

        # set the table model
        header = [item,item,item,item,item,item]
        self.tablemodel = CustomTableModel(self)
        self.tablemodel.setHeader(header)
        tv.setModel(self.tablemodel)

        # set the minimum size
        tv.setMinimumSize(400, 300)

        # hide grid
        tv.setShowGrid(False)

        # hide vertical header
        vh = tv.verticalHeader()
        vh.setVisible(False)

        # set horizontal header properties
        hh = tv.horizontalHeader()
        hh.setStretchLastSection(True)

        # set column width to fit contents
        tv.resizeColumnsToContents()

        # set row height
        tv.resizeRowsToContents()

        # enable sorting
        tv.setSortingEnabled(False)
        tv.setSelectionMode(QtWidgets.QAbstractItemView.SingleSelection)
        return tv

    def test(self):
        speaker_start = QtWidgets.QTableWidgetItem()
        speaker_start.setText(str(self.c+1))
        
        t = QtWidgets.QTableWidgetItem()
        t.setText("data2")
        # self.tablemodel.insertRow(1,speaker_start,speaker_start,speaker_start,speaker_start,speaker_start)
        self.conversation_table.insertRow(self.c)
        self.conversation_table.setItem(self.c, 0, speaker_start)
        self.conversation_table.setItem(self.c, 1, t)
        self.c = self.c + 1
        print ('success')
        
    def nextButton(self):
        self.conversation_table.nextPage()
        print ('success')
    def prevButton(self):
        self.conversation_table.reDraw(0,self.conversation_table.getMaxItem())
        #print ('success')
        #self.conversation_table.item(11,0).setText("asdf")
        
 
class MyTableWidget(QtWidgets.QWidget):
    def __init__(self, data, *args):
        super(MyTableWidget, self).__init__(*args)
         #-- table model
        tablemodel = CustomTableModel(parent=self)

        #-- table view
        tableview = QtWidgets.QTableView()
        tableview.setModel(tablemodel)

class CustomTableModel(QAbstractTableModel):
    ROW_BATCH_COUNT = 5
    def __init__(self, parent=None):
        """
        Args:
            datain: a list of lists\n
            headerdata: a list of strings
        """
        QAbstractTableModel.__init__(self, parent)
        self.FullData = []
        self.arraydata = []
        self.headerdata = ["1","1","1","1","1","1"]
        self.rowsLoaded = CustomTableModel.ROW_BATCH_COUNT
        self.page = 1
        self.model = QtGui.QStandardItemModel(self)
        
    def insertRow(self,index,speaker_icon,speaker_start,speaker_end,speaker_message,file):
        self.beginResetModel()
        self.FullData.append([index,speaker_icon,speaker_start,speaker_end,speaker_message,file])
        self.arraydata = self.FullData[(self.page-1)*5:(self.page)*5]
        self.endResetModel()
        
    def setHeader(self,header):
        self.headerdata=header

    def rowCount(self,index=QModelIndex()):
        if len(self.arraydata) <= self.rowsLoaded:
            return len(self.arraydata)
        else:
            return self.rowsLoaded

    def columnCount(self, parent):
        if len(self.arraydata) > 0: 
            return len(self.arraydata[0]) 
        return 0
    
    def prevPage(self):
        self.page = self.page - 1
        self.beginResetModel()
        self.arraydata = self.FullData[(self.page-1)*5:(self.page)*5]
        self.endResetModel()
        print((self.page-1)*5,(self.page)*5)
    
    def nextPage(self):
        self.page = self.page + 1
        self.beginResetModel()
        self.arraydata = self.FullData[(self.page-1)*5:(self.page)*5]
        self.endResetModel()
        print((self.page-1)*5,(self.page)*5)
        
    def data(self, index, role):
        if not index.isValid():
            return None
        value = ""
        if (index.column() == 0):
            value = self.arraydata[index.row()][index.column()]
        elif (index.column() == 1):
            icon = self.arraydata[index.row()][index.column()].icon()
            if role == Qt.DecorationRole:
                return icon
        else:
            value = self.arraydata[index.row()][index.column()].text()
            
        if role == QtCore.Qt.EditRole:
            return value
        
        elif role == QtCore.Qt.DisplayRole:
            return value


    def setData(self, index, value, role):
        print(index, value, role)
        if not index.isValid():
            return False
        return True

    def headerData(self, col, orientation, role):
        if orientation == Qt.Horizontal and role == Qt.DisplayRole:
            return QVariant(self.headerdata[col])
        return QVariant()
    
    def update(self,dataIn):
        self.beginResetModel()
        self.FullData.append(dataIn)
        self.arraydata = self.FullData[(self.page-1)*5:(self.page)*5]
        self.endResetModel()
        print ('success')
        
    def flags(self,index):
        return QtCore.Qt.ItemIsEditable | QtCore.Qt.ItemIsEnabled | QtCore.Qt.ItemIsSelectable
    
class CustomTableWidget(QtWidgets.QTableWidget):
    def __init__(self):
        super().__init__()
        self.FullData = {}
        self.pageData = []
        self.pageLimit = 10
        self.pageLimitList = {}
        self.pageLimitList[1] = 9
        self.page = 1
        self.pageListWidget = None
        self.autoSwitchPage =  False
        
        self.ListItemCount = 0
        # self._flag = False
        self.listitemsize = 45
        
        self.bool = True
        
        self.bookmarksList = []
        


    # Right Click function
    def createBookMark(self):
        s = set(self.bookmarksList)
        if self.page not in s:
            self.bookmarksList.append(self.page)
        self.redrawList(self.page)
        print("Added to bookmarks")
        
    def splitPage(self,index):

        if len(self.pageData) == 1:
            return
        
        self.duplicate()
        totalRow = len(self.FullData)
        firstHalf = index
        
        oldvalue = 0
        if self.page+1 in self.pageLimitList:
            tempPage = self.page + 1
            counter = 0
            while tempPage in self.pageLimitList:
                if counter == 0:
                    nextValue = self.pageLimitList[tempPage]
                    oldvalue = nextValue
                    currentValue = self.pageLimitList[tempPage-1]
                    self.pageLimitList[tempPage] = currentValue
                else:
                    oldvalue = nextValue
                    nextValue = self.pageLimitList[tempPage]
                    self.pageLimitList[tempPage] = oldvalue
                tempPage = tempPage + 1
                counter = counter + 1
            self.pageLimitList[tempPage] = oldvalue + self.pageLimit
        else:
            self.pageLimitList[self.page+1] = firstHalf + self.pageLimit
        self.pageLimitList[self.page] = firstHalf
        self.page = self.page + 1
        self.pageData = self.getPageSlice()
        self.setRowCount(0)
        self.buildPage()
        self.addNewPageItem()
        
    ## general function
    def getMaxItem(self):
        width = self.pageListWidget.frameGeometry().width()
        maxItem = int(width/self.listitemsize)
        return maxItem        
    
   
    def switchPage(self,pageID):
        self.pageData = self.getPageSlice()
        self.duplicate()
        self.page = pageID
        self.pageData = self.getPageSlice()
        self.setRowCount(0)
        print("Page : " + str(self.page))
        self.buildPage()
        pass

# 1 2 3 4 5 6 7 8 9 10
# 1 2 3 4 5 / 6 7 8 9 10
# 1 2 3 4 5 / 6 7 8 / 9 10

# 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15
# 1 2 3 4 5 / 6 7 8 9 10 11 12 13 14 15
# 1 2 3 4 5 / 6 7 8 9 10 11 12 13 / 14 15
# 1 2 3 4 5 / 6 7 8 9 10/ 11 12 13 / 14 15

    def duplicate(self):
        counter = 0
        startKey = self.page * self.pageLimit - self.pageLimit
        lp, up = self.getLimits2(self.page)
        for i in range(up-lp):
            if (lp+i+1) in self.FullData:
                self.FullData[lp+i+1][1] = True
            else:
                break
        for key in self.FullData:
            if(self.FullData[key][1]):
                rowData = self.FullData[key]
                self.FullData[key][0] = rowData[0]
                self.FullData[key][1] = False
                colIndex = 2
                for data in rowData:
                    if isinstance(data,QtWidgets.QTableWidgetItem):
                        dup = QtWidgets.QTableWidgetItem()
                        dup.setText(data.text())
                        dup.setData(QtCore.Qt.UserRole,data.data(QtCore.Qt.UserRole))
                        dup.setBackground(data.background())
                        dup.setFont(data.font())
                        dup.setIcon(data.icon())
                        self.FullData[key][colIndex] = dup
                        colIndex = colIndex + 1
                      
    def buildPage(self):
        counter = 0
        for data in self.pageData:
            super().insertRow(counter)
            item_count = 0
            for item in data:
                if isinstance(item,QtWidgets.QTableWidgetItem):
                    super().setItem(counter,item_count,item)
                    item_count = item_count + 1
            counter = counter + 1

    def nextPage(self):
        if(self.page + 1) > len(self.pageLimitList) : return
        self.duplicate()
        self.page = self.page + 1
        self.pageData = self.getPageSlice()
        self.setRowCount(0)
        print("Page : " + str(self.page))
        self.buildPage()
        self.redrawList(self.page)
        pass
    
    def prevPage(self):
        if(self.page - 1) == 0: return
        self.duplicate()
        self.page = self.page - 1
        self.pageData = self.getPageSlice()
        self.setRowCount(0)
        print("Page : " + str(self.page))
        self.buildPage()
        self.redrawList(self.page)

    def getPageSlice(self):
        dict_items = self.FullData.items()
        pagesize = self.pageLimitList[self.page]
        lowerlimit,upperlimit = self.getLimits()
        listData = []
        for i in range((upperlimit+1)-(lowerlimit+1)):
            if i+lowerlimit+1 in self.FullData:
                listData.append(self.FullData[i+lowerlimit+1])
            else: break
        return listData
        # return list(dict_items)[lowerlimit+1:upperlimit+1]
             
    def setAutoSwitchPage(self, boolean):
        self.bool = boolean
        if self.bool:
            self.pageListWidget.model().rowsInserted.connect(self._recalcultate_height)
            self.pageListWidget.model().rowsRemoved.connect(self._recalcultate_height)
    
    def isPageFull(self):
        pagesize = len(self.pageData)
        lowerlimit,upperlimit = self.getLimits()
        pagelimit = upperlimit - lowerlimit
        if pagesize >=  pagelimit:
            return True
        return False
    
    def getLimits2(self,pageID):
        if pageID-1 == 0:
            lowerlimit = -1
        else:
            lowerlimit = self.pageLimitList[pageID-1]
        if(pageID) in self.pageLimitList: 
            upperlimit = self.pageLimitList[pageID]
        else:
            upperlimit = lowerlimit + self.pageLimit
        return lowerlimit,upperlimit
    
    def getLimits(self):
        if self.page-1 == 0:
            lowerlimit = -1
        else:
            lowerlimit = self.pageLimitList[self.page-1]
        if(self.page) in self.pageLimitList: 
            upperlimit = self.pageLimitList[self.page]
        else:
            upperlimit = len(self.FullData)
        return lowerlimit,upperlimit
        
    
    
    ## List view functions ## 
    def redrawList(self,selectedPage):                       
        width = self.pageListWidget.frameGeometry().width()
        maxItem = int(width/self.listitemsize)
        half = maxItem/2
        if maxItem%2 ==0:    
            offset = int(selectedPage-half)+1
        else:
            offset =  int(selectedPage-half)+1
            half = half-0.5
        if offset <=0:
            offset=1
        if selectedPage + half >= self.ListItemCount :
            offset = self.ListItemCount - maxItem + 1
        self.pageListWidget.model().rowsInserted.disconnect()
        self.pageListWidget.model().rowsRemoved.disconnect() 
        self.pageListWidget.clear()
        for i in range(maxItem):
            if i+offset <=0:
                continue
            if i+offset > self.ListItemCount:
                continue
            item1 = QtWidgets.QListWidgetItem(str(i+offset))
            item1.setData(Qt.UserRole,i+offset)
            item1.setTextAlignment(Qt.AlignCenter)
            item1.setSizeHint(QSize (self.listitemsize,1))
            self.pageListWidget.addItem(item1) 
            
        self.pageListWidget.model().rowsInserted.connect(self._recalcultate_height)
        self.pageListWidget.model().rowsRemoved.connect(self._recalcultate_height)
        s = set(self.bookmarksList)
        for i in range(self.pageListWidget.count()):
            item = self.pageListWidget.item(i)
            if str(int(item.text()))==str(selectedPage):
                f = item.font()
                f.setBold(True)
                item.setFont(f)
            if int(item.text()) in s:
                fg = item.foreground().color()
                fg.setRed(255)
                item.setForeground(fg)
                
    def setpageListWidget(self, pageListWidget):
        self.pageListWidget = pageListWidget

    
    def addNewPageItem(self):
        numOfItem = self.ListItemCount
        self.ListItemCount = self.ListItemCount + 1
        if self.bool:
            item1 = QtWidgets.QListWidgetItem(str(numOfItem+1) )
            item1.setData(Qt.UserRole,numOfItem+1)
            item1.setSizeHint(QSize (self.listitemsize,1))
            self.pageListWidget.addItem(item1) 
            self.pageListWidget.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
            self.pageListWidget.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        
    def _recalcultate_height(self):
        if self.bool:
            self.redrawList(self.page)
            
    # def reDraw(self,startItem,maxItem):
    #     self.pageListWidget.model().rowsInserted.disconnect()
    #     self.pageListWidget.model().rowsRemoved.disconnect() 
    #     self.pageListWidget.clear()
        
    #     for i in range(maxItem):
    #         item1 = QtWidgets.QListWidgetItem(str(i+startItem+1))
    #         item1.setData(Qt.UserRole,i+startItem+1)
    #         item1.setSizeHint(QSize (self.listitemsize,1))
    #         item1.setTextAlignment(Qt.AlignCenter)
    #         self.pageListWidget.addItem(item1) 
            
    #     self.pageListWidget.model().rowsInserted.connect(self._recalcultate_height)
    #     self.pageListWidget.model().rowsRemoved.connect(self._recalcultate_height)
    #     for i in range(self.pageListWidget.count()):
    #         item = self.pageListWidget.item(i)
    #         if str(item.text())==str(self.page):
    #             f = item.font()
    #             f.setBold(True)
    #             item.setFont(f)
                
    def resizeEvent(self, event):
        if self.bool:
            self.redrawList(self.page)
        super().resizeEvent(event)
    
    
    ## Table Function
    def setItem(self,index,col,item):
        lowerlimit,upperlimit = self.getLimits2(self.page)
        if index > lowerlimit and index <= upperlimit:
            super().setItem(index-lowerlimit-1,col,item)
        if index in self.FullData:
            self.FullData[index][col+2] = item
            self.FullData[index][1] = True
        else:
            self.FullData[index] = [index,True,None,None,None,None,None,None]
            self.FullData[index][col+2] = item
        self.pageData = self.getPageSlice()
        if(self.autoSwitchPage):
            if self.bool == False: return
            if self.page != len(self.pageLimitList)-1: return
            
            self.switchPage(self.page+1)
            self.redrawList(self.page)
            self.autoSwitchPage = False
        
    def insertRow(self,index):
        if(index == 0):
            self.addNewPageItem() 
        if not self.isPageFull():
            super().insertRow(super().rowCount())
        else: ## current view page is full
            totalRow = len(self.FullData) - 1
            lowerlimit,upperlimit = self.getLimits2(len(self.pageLimitList))
            if(totalRow >= upperlimit):
                self.addNewPageItem() 
                self.pageLimitList[len(self.pageLimitList)+1] = upperlimit + self.pageLimit
                self.autoSwitchPage = True
                
    def item(self, row, col):
        return self.FullData[row][col+2]
    
    def currentRow(self):
        pageCurrentRow = super().currentRow()
        if self.page-1 in self.pageLimitList:
            dataCurrentRow = self.pageLimitList[self.page-1] + pageCurrentRow + 1
        else:
            dataCurrentRow = pageCurrentRow
        return dataCurrentRow

    def rowCount(self):
        return len(self.FullData)
    
    
if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    w = MyWindow()
    w.show()
    sys.exit(app.exec_())